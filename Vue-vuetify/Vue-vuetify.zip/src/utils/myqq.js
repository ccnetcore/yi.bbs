const myqqLogin = {
    appId: "101951505",
    redirectURI: "https://jiftcc.com/qq?state=0",
};
const myqqUpdate = {
    appId: "101951505",
    redirectURI: "https://jiftcc.com/qq?state=1",
};
export default { myqqLogin, myqqUpdate };