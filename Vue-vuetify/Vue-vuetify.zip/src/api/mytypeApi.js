import myaxios from '@/utils/myaxios'
export default {
    getMytypes() {
        return myaxios({
            url: '/Mytype/getMytypes',
            method: 'get'
        })
    },
    addMytype(mytype) {
        return myaxios({
            url: '/Mytype/addMytype',
            method: 'post',
            data: mytype
        })
    },
    updateMytype(Mytype) {
        return myaxios({
            url: '/Mytype/UpdateMytype',
            method: 'post',
            data: Mytype
        })
    },
    delMytypeList(Ids) {
        return myaxios({
            url: '/Mytype/DelMytypeList',
            method: 'post',
            data: Ids
        })
    },
}